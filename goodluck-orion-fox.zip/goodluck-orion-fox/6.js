/*
Function angkaPrimaRange adalah function menerima angka dan memiliki 
ouput array berisi angka-angka perima sebelum angka tersesbut
cobalah kerjakan soal ini dengan modular function 

Rules : 
Dilarang menggunakan built-in function selain .push()
*/

function angkaPrima(angka) {
    // your code here
}

function angkaPrimaRange(num) {
    // your code here
}

// TEST CASES
console.log(angkaPrimaRange(6)); // [ 1, 2, 3, 5 ]
console.log(angkaPrimaRange(33)); // [ 1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31 ]